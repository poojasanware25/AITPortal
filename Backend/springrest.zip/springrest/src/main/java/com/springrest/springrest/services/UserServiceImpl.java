package com.springrest.springrest.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springrest.springrest.dao.UserDao;

import com.springrest.springrest.entities.User;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;


	public UserServiceImpl() {
		// list=new ArrayList<>();
		// list.add(new User(1,"pooja","sanware","pooja@company.com","pooja@"));

	}

	@Override
	public List<User> getUsers() {
		return userDao.findAll();

	}

	@Override
	public User addUser(User user) {
		userDao.save(user);
		return user;
	}

	@Override
	public User updateUser(User user) {
		userDao.save(user);
		return user;
	}

	@Override
	public void deleteUser(long parseLong) {
		User entity = userDao.getOne(parseLong);
		userDao.delete(entity);
	}

	@Override
	public User fetchUserByEmailId(String email) {
		return userDao.findByEmail(email);
	}

	// login authentication
	@Override
	public User fetchUserByEmailIdAndPassword(String email, String password) {
		return userDao.findByEmailAndPassword(email, password);
	}

}
